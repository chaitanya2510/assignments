package com.University;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityResultAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityResultAppApplication.class, args);
	}

}
