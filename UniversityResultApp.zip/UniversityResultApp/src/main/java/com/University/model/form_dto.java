package com.University.model;

public class form_dto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
