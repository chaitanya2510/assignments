package com.neo.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeoBookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeoBookStoreApplication.class, args);
	}

}




//When we have to connect with embedded derby database
//add derby dependency in pom.xml, data jpa and change the services based on repositories methods
    //spring.datasource.url=jdbc:mysql://localhost/bookstore
	//spring.datasource.username=dbuser
	//spring.datasource.password=dbpass
	//spring.datasource.driver-class-name=com.mysql.jdbc.Driver