package com.neo.store.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.neo.store.model.OrderTemp;

@Repository
public interface OrderTempRepo extends CrudRepository<OrderTemp, String>{

	List<OrderTemp> findByUserId(String id);

}
