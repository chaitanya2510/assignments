package com.neo.store.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.neo.store.model.LoginModel;
import com.neo.store.model.UserModel;
import com.neo.store.repository.UserRepository;



@RestController                          // @Controller+@ResponseBody
public class LoginController {

	@Autowired
	UserRepository userRepo;
	
	@ResponseBody
	@PostMapping("/login")
	public boolean checkUser(@RequestBody LoginModel data) {
		System.out.println(data);
		Optional<UserModel> user = userRepo.findById(data.getEmail());
		if(user.isEmpty()) {
			System.out.println("false");
			return false;
		}else {
			if(user.get().getPassword().equals(data.getPassword())) {
				System.out.println("true");
				return true;				
			}else {
				System.out.println("false");
				return false;
			}
		}
	}
}
