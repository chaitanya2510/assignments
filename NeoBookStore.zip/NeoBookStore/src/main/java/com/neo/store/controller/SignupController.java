package com.neo.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.neo.store.model.UserTempModel;
import com.neo.store.service.UserService;


@RestController
public class SignupController {

	@Autowired
	UserService userService;
    @RequestMapping(method=RequestMethod.POST,value="/signup")
//	@PostMapping("/signup")
	public boolean saveUser(@RequestBody UserTempModel user) {
		System.out.println(user);
		return userService.saveUser(user).equals("success") ? true : false;
	}
}
