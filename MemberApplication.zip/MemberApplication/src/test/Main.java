package test;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
public static void main(String[] args) {
	
	
	Library lib=new Library();
	Scanner sc=new Scanner(System.in);
	
	
	while(true) {
	System.out.println("1. Add Member"+"\n"+"2. View all member"+"\n"+"3. View member by Address "+"\n"+"4. Exist");
	System.out.println("Enter Your Choice");
	int i=sc.nextInt();
	
	switch(i) {
	case 1:
		System.out.println("enter id:");
		int id=sc.nextInt();
		System.out.println("enter name:");
		String name=sc.next();
		System.out.println("enter address:");
		String address=sc.next();
		lib.addMember(new Member(id,name,address));
		break;
	case 2:
		ArrayList<Member> li=(ArrayList<Member>) lib.viewAllMember();
		if(li.isEmpty()) {
			System.out.println("List is Empty");
		}else {
		for(int m=0;i<li.size();i++) {
			System.out.println("[ "+li.get(i).getId()+" "+li.get(i).getMemberName()+" "+li.get(i).getAddress()+" ]");
		}
		}
		break;
	case 3:
		System.out.println("Enter Address");
		String a=sc.next();
		ArrayList<Member> l2=(ArrayList<Member>) lib.viewByAddress(a);
		if(l2.isEmpty()) {
			System.out.println("List is Empty");
		}else {
		for(int m=0;i<l2.size();i++) {
			System.out.println("[ "+l2.get(i).getId()+" "+l2.get(i).getMemberName()+" "+l2.get(i).getAddress()+" ]");
		}
		}
		break;
	case 4:
		break;
	}
	}
}
	
}
