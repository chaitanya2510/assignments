package test;

public class Member {

	private int id;
	String memberName;
	String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Member(int id, String memberName, String address) {
		super();
		this.id = id;
		this.memberName = memberName;
		this.address = address;
	}
	public Member() {
		super();
	}
	
	
}
