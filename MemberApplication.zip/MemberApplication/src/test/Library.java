package test;

import java.util.ArrayList;
import java.util.List;

public class Library {
  
	ArrayList<Member> list=new ArrayList();
	public void addMember(Member obj) {
		list.add(obj);
	}
	public List<Member> viewAllMember(){
		return list;
	}
	public List<Member> viewByAddress(String address){
		ArrayList li=new ArrayList();
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getAddress().equals(address)) {
				li.add(list.get(i));
			}
		}
		return li;
	}
}
