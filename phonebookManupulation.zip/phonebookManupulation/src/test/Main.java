package test;

import java.util.*;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	PhoneBook book=new PhoneBook();
	while(true) {
	System.out.println("1. Add Contact"+"\n"+"2. Display All Contact"+"\n"+"3. Search Contact by phone"+"\n"+"4. Remove Contact"+"\n"+"5. exit");
    System.out.println("Enter Your Choice");
    int i=sc.nextInt();
    switch(i) {
    case 1:
    	System.out.println("Enter 1st Name :");
    	String firstName=sc.next();
    	System.out.println("Enter Last Name :");
    	String lastName=sc.next();
    	System.out.println("Enter phone no :");
    	Long phoneNo=sc.nextLong();
    	System.out.println("Enter Mail ID :");
    	String mail=sc.next();
    	System.out.println(
    	book.addContact(new Contact(firstName,lastName,phoneNo,mail))
    			);
    	break;
    case 2:
    	book.vieAllContact();
    	
    	break;
    case 3:
    	System.out.println("Enter Phone No");
    	Long no=sc.nextLong();
    	Contact contact=book.viewContactGivenNo(no);
    	System.out.println("[ "+contact.getFirstName()+" "+contact.getLastName()+" "+contact.getPhoneNo()+" "+contact.getMailID()+" ]");
    	break;
    case 4:
    	System.out.println("Enter Phone No");
    	Long n=sc.nextLong();
    	System.out.println(book.removeConatact(n));
    	break;
    case 5:
    	break;
    }
}}
}
