package test;

import java.util.*;

public class PhoneBook {
List<Contact> phoneBook=new ArrayList();

public List getPhoneBook() {
	return phoneBook;
}

public void setPhoneBook(List phoneBook) {
	this.phoneBook = phoneBook;
}
public boolean addContact(Contact obj) {
	try{
		phoneBook.add(obj);
		return true;
		}catch(Exception e) {
			System.out.println(e);
			return false;
		}
}
public List<Contact> vieAllContact(){
	if(phoneBook.isEmpty()) {
		System.out.println("Empty List");
	}else {
		try {
	for(int m=0;m<phoneBook.size()-1;m++) {
		Contact contact1=phoneBook.get(m);
		System.out.println("[ "+contact1.getFirstName()+" "+contact1.getLastName()+" "+contact1.getPhoneNo()+" "+contact1.getMailID()+" ]");
	}}catch(Exception e) {
		System.out.println(e);
	}
	}	
	return phoneBook;
}
public Contact viewContactGivenNo(Long no) {
	for(int i=0;i<phoneBook.size();i++) {
		if(phoneBook.get(i).getPhoneNo().equals(no)) {
			return phoneBook.get(i);
		}
	}
	return null;
}
public boolean removeConatact(Long no) {
	for(int i=0;i<phoneBook.size();i++) {
		if(phoneBook.get(i).getPhoneNo().equals(no)) {
			phoneBook.remove(i);
			return true;
		}
	}
	return false;
}
}
