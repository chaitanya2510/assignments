package test;

public class Contact {
private String firstName;
private String lastName;
private Long phoneNo;
private String mailID;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Long getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(Long phoneNo) {
	this.phoneNo = phoneNo;
}
public String getMailID() {
	return mailID;
}
public void setMailID(String mailID) {
	this.mailID = mailID;
}
public Contact(String firstName, String lastName, Long phoneNo, String mailID) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.phoneNo = phoneNo;
	this.mailID = mailID;
}
public Contact() {
	super();
}

}
