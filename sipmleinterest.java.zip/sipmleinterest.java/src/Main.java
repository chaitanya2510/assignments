
	public class Main
	{
	public static void main (String args[])
	{ float p, r, t, si; 
	// principal amount, rate, time and simple interest respectively
	p = 20000; r = 12; t = 2;
	si = (p*r*t)/100;
	System.out.println("Simple Interest is: " +si);
	}}
